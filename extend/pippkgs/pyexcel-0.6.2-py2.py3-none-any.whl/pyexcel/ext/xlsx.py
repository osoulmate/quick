"""
    pyexcel.ext.xlsx
    ~~~~~~~~~~~~~~~~~~~~~~~~

    Deprecated module import

    :copyright: (c) 2015-2020 by Onni Software Ltd.
    :license: New BSD License
"""
from ..deprecated import deprecated_pyexcel_ext

deprecated_pyexcel_ext("0.2.2", __name__)
